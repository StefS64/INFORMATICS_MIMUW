from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect
from django.contrib.auth import login
from .models import Route, BackgroundImage, Point
from .forms import RouteForm, PointForm
from django.shortcuts import get_object_or_404
from django.db.models import Max
from django.http import HttpResponseRedirect


def register(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            user.save()
            login(request, user)
            return redirect('home')
    else:
        form = UserCreationForm()
    return render(request, 'registration/register.html', {'form': form})

@login_required
def home(request):
    routes = Route.objects.filter(user=request.user)
    return render(request, 'mapeditor/home.html', {'routes': routes})

@login_required
def create_route(request):
    if request.method == "POST":
        form = RouteForm(request.POST)
        if form.is_valid():
            route = form.save(commit=False)
            route.user = request.user
            route.save()
            return redirect('route_detail', route_id=route.id)
    else:
        form = RouteForm()
    backgrounds = BackgroundImage.objects.all()
    return render(request, 'mapeditor/create_route.html', {'form': form, 'backgrounds': backgrounds})

@login_required
def route_detail(request, route_id):
    route = get_object_or_404(Route, id=route_id, user=request.user)
    points = route.points.all()

    if request.method == "POST":
        form = PointForm(request.POST)
        if form.is_valid():
            point = form.save(commit=False)
            point.route = route
            # If order is not specified, set to max+1
            if point.order in [None, '']:
                max_order = route.points.aggregate(Max('order'))['order__max'] or 0
                point.order = max_order + 1
            point.save()
            return redirect('route_detail', route_id=route.id)
    else:
        form = PointForm()

    return render(request, 'mapeditor/route_detail.html', {'route': route, 'points': points, 'form': form})

@login_required
def delete_point(request, point_id):
    point = get_object_or_404(Point, id=point_id, route__user=request.user)
    route_id = point.route.id
    if request.method == "POST":
        point.delete()
    return redirect('route_detail', route_id=route_id)

