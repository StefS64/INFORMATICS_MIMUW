from django.contrib import admin
from .models import BackgroundImage, Route, Point

admin.site.register(BackgroundImage)
admin.site.register(Route)
admin.site.register(Point)
