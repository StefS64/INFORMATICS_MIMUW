package pl.edu.mimuw.commissions;

public enum CommissionType {
    SELL,
    BUY
}
