package pl.edu.mimuw.commissions;

public enum ValidityTime {
    FILLORKILL,
    IMMIDIATE,
    NEVERENDING,
    TIMEDCOMMISION
}
