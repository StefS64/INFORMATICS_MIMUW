### Niemutowalna tablica liczb całkowitych

Zaimplementuj klasę `Fraction`, reprezentującą ułamek. Klasa ta powinna wspierać
metody pozwalające na dodanie, odjęcie, pomnożenie oraz podzielenie przez inny
ułamek. Dla licznika i mianownika użyj klasy `BigInteger`. Design klasy powinien
być niemutowalny. Zastanów się także nad wygodnym tworzeniem instancji klasy.

Wszystkie funkcjonalności klasy powinny być przetestowane. Rozważ zastosowanie
podejścia TDD.
