package pl.edu.mimuw.expression;

public abstract class Expression {

    public abstract double evaluate(double x);
    public abstract String toString();

}
