#ifndef INPUT_OUTPUT_H
#define INPUT_OUTPUT_H

extern int read_int(void);
extern void print_uint(unsigned value);

#endif /* INPUT_OUTPUT_H */
