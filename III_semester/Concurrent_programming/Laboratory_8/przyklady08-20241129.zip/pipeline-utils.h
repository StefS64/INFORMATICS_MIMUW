#ifndef MIM_PIPELINE_UTILS_H
#define MIM_PIPELINE_UTILS_H

#include <sys/types.h>

void print_open_descriptors(void);

#endif