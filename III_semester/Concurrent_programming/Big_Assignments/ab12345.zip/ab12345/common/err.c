#include "common/err.h"

#include <errno.h>
#include <stdarg.h> // IWYU pragma: keep
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// IWYU pragma: no_include <__stdarg_va_arg.h>

_Noreturn void syserr(const char* fmt, ...)
{
    va_list fmt_args;

    fprintf(stderr, "ERROR: ");

    va_start(fmt_args, fmt);
    vfprintf(stderr, fmt, fmt_args);
    va_end(fmt_args);
    fprintf(stderr, " (%d; %s)\n", errno, strerror(errno));
    exit(1);
}

_Noreturn void fatal(const char* fmt, ...)
{
    va_list fmt_args;

    fprintf(stderr, "ERROR: ");

    va_start(fmt_args, fmt);
    if (vfprintf(stderr, fmt, fmt_args) < 0) {
        fprintf(stderr, " malformed format string? '%s'", fmt);
    }
    va_end(fmt_args);

    fprintf(stderr, "\n");
    exit(1);
}
